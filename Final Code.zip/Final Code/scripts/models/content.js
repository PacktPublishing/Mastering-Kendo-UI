var contentModel=kendo.observable({
  Id: "",
  PageId: "",
  Title: "",
  Content: "",
  canSave: false,
  canEdit: false,
  isAdmin: function(){
    return userModel.isAdmin;
  },

  dataSource: new kendo.data.DataSource({
    type: 'everlive',
    transport: {
      typeName: 'PageContent'
    },
    schema: {
      model: {id: "PageId"}
    }
  }),

  load: function(id){
    var d=$.Deferred();
    contentModel.set("Id", id);
    contentModel.getContent(id)
      .then(function(data){
        contentModel.showContent(data).then(function(){
          d.resolve();
        });
      });
    return d.promise();
  },

  getContent: function(id){
    var d=$.Deferred();
    var model=contentModel.dataSource.get(id);
    d.resolve(model);
    return d.promise();
  },

  showContent: function(data){
    var d=$.Deferred();
    contentModel.set("Title", data.Title);
    contentModel.set("Content", data.Content);
    d.resolve();
    return d.promise();
  },

  saveContent: function(){
    var titleEditor=$("#titleZoneEditor").data("kendoEditor");
    var contentEditor=$("#contentZoneEditor").data("kendoEditor");

    var model=contentModel.dataSource.get(contentModel.get("Id"));

    model.set("Title", titleEditor.value());
    model.set("Content", contentEditor.value());

    contentModel.dataSource.sync();

    contentModel.set("canSave", false);
    contentModel.set("canEdit", false);
  },

  clearContent: function(){
    this.set("Id", "");
    this.set("Title", "");
    this.set("Content", "");
  },

  loadEditor: function(){
    var titleEditor=$("#titleZoneEditor").data("kendoEditor");
    var contentEditor=$("#contentZoneEditor").data("kendoEditor");
    contentModel.set("canSave", false);
    contentModel.set("canEdit", false);

    var titleChanged=false;
    var contentChanged=false;
    $("#titleZoneEditor").kendoEditor({
      tools: ['bold', 'italic', 'underline', 'strikethrough', 'subscript', 'superscript', 'fontName', 'fontSize', 'foreColor', 'backColor',
        'justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'viewHtml'],
      keydown: function(e){
        if(e.which !== 9){
          contentModel.set("canSave", true);
          titleChanged=true;
        }
      },
      select: function(e){
        contentModel.set("canEdit", true);
      },
      change: function(){
        contentModel.set("canSave", true);
      }
    });

    $("#contentZoneEditor").kendoEditor({
      tools: ['bold', 'italic', 'underline', 'strikethrough', 'subscript', 'superscript',
        'fontName', 'fontSize', 'foreColor', 'backColor',
        'justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull',
        'insertUnorderedList', 'insertOrderedList', 'indent', 'outdent',
        'createLink', 'unlink', 'insertImage', 'insertFile',
        'createTable', 'addColumnLeft', 'addColumnRight', 'addRowAbove', 'addRowBelow', 'deleteRow', 'deleteColumn',
        'viewHtml'],
      keydown: function(e){
        if(e.which !== 9){
          contentModel.set("canSave", true);
          contentChanged=true;
        }
      },
      select: function(e){
        contentModel.set("canEdit", true);
      },
      change: function(){
        contentModel.set("canSave", true);
      }
    });

    $("#titleZoneEditor").blur(function(){
      if(!titleChanged&& !contentChanged){
        contentModel.set("canSave", false);
        contentModel.set("canEdit", false);
      }
    });

    $("#contentZoneEditor").blur(function(){
      if(!titleChanged&& !contentChanged){
        contentModel.set("canSave", false);
        contentModel.set("canEdit", false);
      }
    });
  }
});

