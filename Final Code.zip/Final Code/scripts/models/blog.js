//Code complete 9-21-2014
//Blog and Posts are setup for bookmarks

var blogsModel = kendo.observable({
  dataSource: new kendo.data.DataSource({
    type: 'everlive',
    transport: {
      typeName: 'Blogs'
    },
    schema: {
      model: {
        id: Everlive.idField,
        title: Everlive.Title,
        seoTitle: Everlive.SEOTitle
      }
    }
  }),

  loadPosts: function(e){
    e.preventDefault();

    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    router.navigate("posts/?blogId=" + dataItem.Id);
  },

  findBlogBySEOTitle: function(blogTitle){
    var d = $.Deferred();
    $.when(blogsModel._searchByName(blogTitle)).done(function(blog){
      d.resolve(blog);
    }).fail(function(){
      d.reject();
    });
    return d.promise();
  },

  _searchByName: function(blogTitle){
    var d = $.Deferred();
    $.each(blogsModel.dataSource.data(), function(key, item){
      if(item.SEOTitle === blogTitle){
        d.resolve(item);
      }
    });
    return d.promise();
  }
});

var blogId = "";
var postsModel = kendo.observable({
  Id: "",
  Content: "",
  PostDate: "",
  Summary: "",
  Published: "",
  Title: "",
  PublishedDate: "",
  Blog: "",
  BlogId: "",
  inEdit: false,
  Posts :new kendo.data.DataSource({
    type: "everlive",
    transport: {
      typeName: "BlogPosts",
      read: {
        beforeSend: function (xhr) {
          var filter = { "Blog": postsModel.get("BlogId") };
          xhr.setRequestHeader("X-Everlive-Filter", JSON.stringify(filter));
        }
      }
    },
    schema: {
      model: {
        id: Everlive.idField
      }
      // additional configuration
    },
    // additional configuration
  }),
  load: function(blogTitle){
    var d = $.Deferred();

    $.when(blogsModel._searchByName(blogTitle)).done(function(blog){
      postsModel.set("BlogId", blog.Id);
      postsModel.set("Blog", blog);
    });

    if(postsModel.get("BlogId") !== ""){
      postsModel.Posts.read().then(function(){
        d.resolve();
      });
    }
    return d.promise();
  },

  postSelected: function(){
    var listView = $("#blogPostList").data("kendoListView"),
      index = listView.select().index(),
      dataItem = listView.dataSource.view()[index];

    postsModel.set("Blog", dataItem.Blog);

    var seoTitle = dataItem.Title.replace(/\ /g, '-');
    router.navigate("post/" + seoTitle + "/?blogId=" + dataItem.Blog + "&postId=" + dataItem.Id);
  },

  loadPost: function(blogId, postId){
    var d = $.Deferred();

    if((postsModel.Posts === "" || postsModel.Posts === undefined) &&
      ((blogId === undefined || blogId === "") ||
      (postId === undefined || postId === ""))){
      d.reject();
    }
    if(postsModel.Posts.data().length <= 0 && (blogId !== "" && blogId !== undefined) && (postId !== "" && postId !== undefined)){
      var blog = blogsModel.dataSource.get(blogId);
      if(blog !== "" && blog !== undefined){
        $.when(postsModel.load(blog.SEOTitle)).done(function(){
          $.when(postsModel.Posts.get(postId)).done(function(item){
            postsModel._loadPost(item);
            d.resolve();
          }).fail(function(){
            d.reject();
          });
        }).fail(function(){
          d.reject();
        });
      } else {
        d.reject();
      }
    } else if(postsModel.Posts.data().length > 0){
      $.when(postsModel.Posts.get(postId)).done(function(item){
        postsModel._loadPost(item);
        d.resolve();
      }).fail(function(){
        d.reject();
      });
    } else {
      d.reject();
    }

    return d.promise();
  },

  loadPosts: function(blogId){
    var d = $.Deferred();
    postsModel.set("BlogId", blogId);

    if(postsModel.get("BlogId") !== ""){
      postsModel.Posts.read().then(function(){
        d.resolve();
      });
    }
    return d.promise();
  },


  backToBlog: function(){
    router.navigate("#:back");
  },

  editPost: function(e){
    e.preventDefault();

    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));

    postsModel._loadPost(dataItem);
    postsModel.set("inEdit", true);
  },

  deletePost: function(e){
    e.preventDefault();

    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var post = postsModel.Posts.getByUid(dataItem.uid);

    postsModel.Posts.remove(post);
    postsModel.Posts.sync();
  },

  bindAddButton: function(){
    var grid = $("#postsGrid").data("kendoGrid");
    $(".k-grid-toolbar").delegate(".k-grid-add", "click", function(e) {
      e.preventDefault();
      var curBlog = postsModel.get("BlogId");
      postsModel._clearPost();
      postsModel.set("inEdit", true);
      postsModel.set("Blog", blogsModel.dataSource.get(curBlog));
    });
  },

  savePost: function () {
    var post;
    var postDate = kendo.toString(postsModel.get("PostDate"), "g");
    if(postDate === null || postDate === "" || postDate === undefined){
      postsModel.set("PostDate", "");
    } else {
      postsModel.set("PostDate", kendo.toString(postsModel.get("PostDate"), "g"));
    }

    var pubDate = kendo.toString(postsModel.get("PublishedDate"), "g");
    if(pubDate === null || pubDate === "" || pubDate === undefined){
      postsModel.set("PublishedDate", "");
    } else {
      postsModel.set("PublishedDate", kendo.toString(postsModel.get("PublishedDate"), "g"));
    }

    if(postsModel.get("Id") === ""){
      post = {
        "Title": postsModel.get("Title"),
        "Summary": postsModel.get("Summary"),
        "Content": postsModel.get("Content"),
        "PostDate": postsModel.get("PostDate"),
        /* Need to work on this logic*/
        "PublishedDate": postsModel.get("PostDate"),
        "Published": true,
        "Blog": postsModel.get("Blog").Id
      };

      postsModel.Posts.add(post);
      postsModel.Posts.sync();
    } else {
      post = postsModel.Posts.get(postsModel.get("Id"));
      post.Title = postsModel.get("Title");
      post.Summary = postsModel.get("Summary");
      post.Content = postsModel.get("Content");
      post.PostDate = new Date();
      post.PublishedDate = new Date();
      post.Published = true;

      var data = el.data('BlogPosts');
      data.updateSingle({"Id": post.Id, "Title": post.Title, "Summary": post.Summary,
          "Content": post.Content, "PostDate": post.PostDate, "PublishedDate": post.PublishedDate,
          "Published": post.Published, "Blog": post.Blog},
        function(data){
          postsModel.Posts.sync();
        },
        function(error){
          alert(JSON.stringify(error));
        });
    }
    postsModel.set("inEdit", false);
    postsModel._clearPost();
  },

  cancelPost: function(){
    postsModel.set("inEdit", false);
    postsModel._clearPost();
  },

  _loadPost: function(item){
    postsModel.set("Id", item.Id);
    postsModel.set("Blog", item.Blog);
    postsModel.set("Content", item.Content);
    postsModel.set("PostDate", kendo.toString(item.PostDate, "g"));
    postsModel.set("Summary", item.Summary);
    postsModel.set("Published", item.Published);
    postsModel.set("Title", item.Title);
    postsModel.set("PublishedDate", kendo.toString(item.PublishedDate, "g"));
  },

  _clearPost: function(){
    postsModel.set("Id", "");
    postsModel.set("Content", "");
    postsModel.set("PostDate", "");
    postsModel.set("Summary", "");
    postsModel.set("Published", false);
    postsModel.set("Title", "");
    postsModel.set("PublishedDate", "");
  }
});