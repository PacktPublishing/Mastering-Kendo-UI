//Code complete 9-19-2014
var validator,
  userModel=kendo.observable({
    userName: "",
    password: "",
    confirmpassword: "",
    displayName: "",
    isAuthenticated: false,
    isAdmin: false,
    emailAddress: "",
    accountCreated: "",
    id: "",

    init: function(){
      userModel.set("userName", "");
      userModel.set("firstName", "");
      userModel.set("lastName", "");
      userModel.set("password", "");
      userModel.set("confirmpassword", "");
      userModel.set("emailAddress", "");
      userModel.set("isAuthenticated", false);
      userModel.set("accountCreated", false);
    },

    loginUser: function(){
      loaderModel.show();
      $.when(userModel._doLogin()).done(function(){
        $.when(userModel._getUser()).done(function(userDetails){
          userModel.set("displayName", userDetails.DisplayName);
          userModel.set("isAuthenticated", true);
          userModel.set("id", userDetails.Id);
          if(userDetails.Role === "bbf69cc0-3ceb-11e4-861b-edbee7be540e"){
            userModel.set("isAdmin", true);
            loadEditor();
          }else{
            userModel.set("isAdmin", false);
          }
          loaderModel.hide();
          app.router.navigate("#home");
        }).fail(function(){
          console.log('login error');
          loaderModel.hide();
        });
      }).fail(function(){
        console.log('login error');
        loaderModel.hide();
      });
    },

    createClicked: function(e){
      e.preventDefault();
      app.router.navigate("create", true);
      app.navigation.navigationModel.loadCreate();
    },

    createAccount: function(e){
      e.preventDefault();

      loaderModel.show();
      userModel._createValidator();
      if(validator.validate()){
        $.when(userModel._createAccount()).then(function(){
          userModel.set("accountCreated", true);
          userModel.set("userName", "");
          userModel.set("password", "");
          userModel.set("confirmpassword", "");
          loaderModel.hide();
        }).fail(function(data){
          console.log('create error: ' + data);
          loaderModel.hide();
        });
      }else{
        loaderModel.hide();
      }
    },

    logoutUser: function(){
      loaderModel.show();
      userModel.set("isAuthenticated", false);
      userModel.set("isAdmin", false);
      el.Users.logout();
      loaderModel.hide();
      app.router.navigate("#home");
    },

    _createAccount: function(){
      var d=$.Deferred();
      el.Users.register(
        userModel.get('userName'), //username
        userModel.get('password'), //password
        {
          Email: userModel.get('emailAddress'),
          DisplayName: userModel.get('firstName') + " " + userModel.get('lastName'),
          Role: 'Registered'
        }
      ).then(function(){
          d.resolve();
        }, function(error){
          alert(error.message);
          d.reject();
        });
      return d.promise();
    },

    _doLogin: function(){
      var d=$.Deferred();
      el.Users.login(userModel.get('userName'), userModel.get("password"))
        .then(function(data){
          userModel.set("userName", "");
          userModel.set("password", "");
          d.resolve(data.result);
        }, function(error){
          alert(error.message);
          d.reject();
        });
      return d.promise();
    },

    _getUser: function(){
      var d=$.Deferred();
      el.Users.currentUser()
        .then(function(data){
          d.resolve(data.result);
        }, function(error){
          alert(error.message);
          d.reject();
        });
      return d.promise();
    },

    _createValidator: function(){
      validator=$("#createForm").kendoValidator({
        rules: {
          password: function(input){
            if(input.is("[name=confirmpassword]")){
              return input.val() === $("#password").val();
            }
            return true;
          }
        },
        messages: {
          required: "<img src='images/error.png' />",
          password: "What!!!"
        }
      }).data("kendoValidator");
    }
  });