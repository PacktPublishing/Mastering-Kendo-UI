//loader class
loaderModel=kendo.observable({
  docHeight: $(document).height(),
  loader: "",
  init: function(){
    $("body").append("<div id='overlay'><div class='circle'></div><div class='circle1'></div></div>");
    loader=$("#overlay");
    loader.height(loaderModel.get("docHeight"))
      .css({
        'opacity': 0.4,
        'position': 'fixed',
        'top': 0,
        'left': 0,
        'background-color': 'black',
        'width': '100%',
        'z-index': 5000,
        'margin': '0 auto',
        'padding-top': '15em'
      });
  },

  show: function(){
    loader=$("#overlay");
    loader.show();
    //kendo.ui.progress($("#loader"), true);
  },

  hide: function(){
    loader=$("#overlay");
    setTimeout(function(){
      loader.hide();
    }, 500);

    //kendo.ui.progress($("#main"), false);
  }
});