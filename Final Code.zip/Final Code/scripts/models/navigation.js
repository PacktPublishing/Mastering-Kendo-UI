var navigationModel=kendo.observable({
  isAdmin: function(){
    return userModel.isAdmin;
  },

  homeClicked: function(e){
    e.preventDefault();
    app.router.navigate("home", true);
    navigationModel.loadHome();
  },

  loadHome: function(){
    loaderModel.show();
    $.ajax({url: 'views/content.htm', cache: false})
      .done(function(template){
        contentModel.clearContent();
        contentModel.load("1")
          .then(function(){
            currentView=new kendo.View(template, {model: contentModel});
            layout.showIn("#main-layout", currentView);
            if(navigationModel.isAdmin){
              contentModel.loadEditor();
            }
            console.log("navigation.loadHome complete");
          });
      })
      .always(function(){
        //var carouselView = new kendo.View("carousel-template");
        //layout.showIn("#gallery-layout", carouselView);

        //carousel.carouselModel.load();

        $("#gallery-layout").empty();
        $("#ulNavigation>li").removeClass("active");
        $("#liHome").addClass("active");

        loaderModel.hide();
      });
  },

  aboutClicked: function(e){
    e.preventDefault();
    app.router.navigate("about", true);
    navigationModel.loadAbout();
  },

  loadAbout: function(){
    loaderModel.show();
    $.ajax({url: 'views/content.htm', cache: false})
      .done(function(template){
        contentModel.clearContent();
        contentModel.load("2")
          .then(function(){
            currentView=new kendo.View(template, {model: contentModel});
            layout.showIn("#main-layout", currentView);
            if(navigationModel.isAdmin){
              contentModel.loadEditor();
            }
          });
      })
      .always(function(){

        $("#gallery-layout").empty();
        $("#ulNavigation>li").removeClass("active");
        $("#liAbout").addClass("active");

        loaderModel.hide();
      });
  },

  loadCreate: function(){
    loaderModel.show();

    $.ajax({url: 'views/create.htm', cache: false})
      .done(function(template){
        userModel.init();
        var createView=new kendo.View(template, {model: userModel});
        layout.showIn("#main-layout", createView);
      })
      .always(function(){
        $("#gallery-layout").empty();
        $("#ulNavigation>li").removeClass("active");

        loaderModel.hide();
      });
  },

  loadContact: function(){
    loaderModel.show();

    $.ajax({url: 'views/contact.htm', cache: false})
      .done(function(template){
        contactModel.init();
        var contactView=new kendo.View(template, {model: contactModel});
        layout.showIn("#main-layout", contactView);
      })
      .always(function(){
        $("#gallery-layout").empty();
        $("#ulNavigation>li").removeClass("active");
        $("#liContact").addClass("active");

        loaderModel.hide();
      });
  },

  loadAccount: function(){
    loaderModel.show();
    if(user.userModel.get("isAuthenticated") === false){
      alert("you must login...");
      router.navigate("home");
    }else{

    }
    $("#gallery-layout").empty();
    $("#ulNavigation>li").removeClass("active");

    loaderModel.hide();
  },

  loadBlog: function(blogName){
    loaderModel.show();
    postsModel.load(blogName).done(function(){

      $.ajax({url: 'views/blog.htm', cache: false})
        .done(function(template){
          var blogView=new kendo.View(template, {model: postsModel});
          layout.showIn("#main-layout", blogView);

          $("#ulNavigation>li").removeClass("active");
          $("#blogMenu-layout").addClass("active");
          loaderModel.hide();
        })
        .always(function(){
          $("#gallery-layout").empty();
          $("#ulNavigation>li").removeClass("active");
          $("#liContact").addClass("active");

          loaderModel.hide();
        });
    });
  },

  loadPost: function(params){
    loaderModel.show();
    postsModel.loadPost(params.blogId, params.postId).done(function(){

      $.ajax({url: 'views/post.htm', cache: false})
        .done(function(template){
          var postView=new kendo.View(template, {model: postsModel});
          layout.showIn("#main-layout", postView);

          $("#ulNavigation>li").removeClass("active");
          $("#blogMenu-layout").addClass("active");
          loaderModel.hide();
        });
    });
  },

  loadBlogManager: function(){
    loaderModel.show();

    $.ajax({url: 'views/admin/blogmanager.htm', cache: false})
      .done(function(template){
        var blogsManagerView=new kendo.View(template, {model: blogsModel});
        layout.showIn("#main-layout", blogsManagerView);
      });

    $("#gallery-layout").empty();
    $("#ulNavigation>li").removeClass("active");

    loaderModel.hide();
  },

  init: function(){
    //
  },

  loadPostManager: function(params){
    loaderModel.show();
    postsModel.loadPosts(params.blogId).done(function(){

      $.ajax({url: 'views/admin/postsmanager.htm', cache: false})
        .done(function(template){
          var postManagerView=new kendo.View(template, {model: postsModel});
          layout.showIn("#main-layout", postManagerView);

          postsModel.bindAddButton();
          $("#ulNavigation>li").removeClass("active");
          $("#blogMenu-layout").addClass("active");
          loaderModel.hide();
        });
    });
  }
});