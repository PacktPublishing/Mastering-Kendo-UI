var contactModel = kendo.observable({
	firstName: "",
	lastName: "",
	emailAddress: "",
	userComments: "",
	emailSent: false,
	init: function(){
		contactModel.set("firstName", "");
		contactModel.set("lastName", "");
		contactModel.set("emailAddress", "");
		contactModel.set("userComments", "");
		contactModel.set("emailSent", "");
	},

	sendContactInformation: function(e){
		e.preventDefault();

		loader.show();
		var validator = $("#contactForm").kendoValidator().data("kendoValidator");

		if (validator.validate()) {

			contactModel._sendContact(function(response){
				loader.hide();
				if(response.result){
					contactModel.set("emailSent", true);
					//alert("Email sent");
					setTimeout(function(){
						contactModel.init();
					}, 5000);
				} else {
					contactModel.set("emailSent", false);
					alert(response.data);
				}

			});

		} else {
			loader.hide();
		}
	},

	_sendContact: function(response){
		var attributes = {
			"Recipients": [
				"charles.catron@gmail.com"
			],
			"FromEmail": contactModel.get("emailAddress"),
			"FromName": contactModel.get("firstName") + " " + contactModel.get("lastName"),
			"Message": contactModel.get("userComments")
		};

		$.ajax({
			type: "POST",
			url: "https://platform.telerik.com/bs-api/v1/5KdOMvZz9Nuq97em/Functions/SendContactEmail",
			contentType: "application/json",
			data: JSON.stringify(attributes),
			success: function(data) {
				response({ result: true, data: data });
			},
			error: function(error) {
				response({ result: false, data: error.message });
			}
		});
	}
});