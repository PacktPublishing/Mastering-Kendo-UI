var ENTER_KEY=13;
var ESC_KEY=27;

var el=new Everlive('YOUR-API-KEY');

var layout, router, currentView,
  headers={
    'X-Parse-Application-Id': 'YOUR-APPLICATION-ID',
    'X-Parse-REST-API-Key': 'YOUR-REST-API-KEY'
  };
$(function(){
  // render a layout in to the "#main" element
  layout=new kendo.Layout("layout-template");
  layout.render("#main");

  router=new kendo.Router({
    routeMissing: function(e){
      console.log('route missing for: ' + e.url);
    }
  });

  router.bind("change", function(e){
    console.log("change event", e);
  });

  router.route("about", function(id){
    navigationModel.loadAbout();
  });
  router.route("home", function(){
    navigationModel.loadHome();
  });
  router.route("contact", function(){
    navigationModel.loadContact();
  });
  router.route("create", function(){
    navigationModel.loadCreate();
  });
  router.route("blog/*blogname", function(blogName){
    navigationModel.loadBlog(blogName);
  });
  router.route("post/*postname", function(postname, params){
    navigationModel.loadPost(params);
  });
  router.route("blogs", function(e){
    if(userModel.isAdmin === false){
      return;
    }
    navigationModel.loadBlogManager();
  });

  router.route("posts/*", function(params){
    if(userModel.isAdmin === false){
      return;
    }
    navigationModel.loadPostManager(params);
  });
  router.route("/", function(){
    navigationModel.loadHome();
  });
  app.router=router;
  buildNav().done(function(){
    $(function(){
      //go get all the content from everlive then kick off the router.
      contentModel.dataSource.fetch(function(){
        userModel.set("userName", "YOUR ADMIN ACCOUNT");
        userModel.set("password", "YOUR ADMIN PASSWORD");
        userModel.loginUser();
        setTimeout(function(){

          router.start();
          loaderModel.init();
          loaderModel.hide();
        }, 1000);
      });
    });
  });

  function buildNav(){
    var d=$.Deferred();

    blogsModel.dataSource.fetch(function(){
      //define the navigationView and show it in the layout template
      $.ajax({url: 'views/navigation.htm', cache: false})
        .done(function(template){
          var navigationView=new kendo.View(template, {model: navigationModel});
          layout.showIn("#navigation-layout", navigationView);
          //Use the data for the blogs to build the blogs menu item in the navaigation template
          $.ajax({url: 'views/blogsmenu.htm', cache: false})
            .done(function(template){
              var tmpl=kendo.template(template);
              var data=blogsModel.dataSource.data();
              $("#blogMenu-layout").html(tmpl(data));
              //Once the navigation view is loaded and applied to the layout get the login template
              $.ajax({url: 'views/login.htm', cache: false})
                .done(function(template){
                  loginView=new kendo.View(template, {model: userModel});
                  layout.showIn("#login-layout", loginView);
                  //return deferred.resolve to signal that the navigation and the login templates are done
                  d.resolve();
                });
            });
        });
    });
    return d.promise();
  }
});